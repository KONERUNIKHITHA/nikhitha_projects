<!DOCTYPE html>
<html lang="en">
<head>
  <title>SE PROJECT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<style>
img{
    width:100%;
    height:100%;
}
 ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: blue;
  position: top;
  
}
.s{
    width:120%;
    height:100%;
}
.s1{
    
    width:99%;
    height:29%;
}
li {
  border-left: white;
}
li a {
  display: block;
  color: black;
  text-align: center;
  padding: 15px 46px;
  text-decoration: none;
  font-size: 20px;
}
li a:hover:not(.active) {
  background-color: rgb(130, 131, 138);
  text-decoration: none;
}

</style>
<ul>
    <li style="float:right"><a href="products.php"><b>Start Ordering</b></a></li>
  </ul>

<center><header><h2>Welcome to Food Villa </h2></header></center>

<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  
  <div class="carousel-inner" data-bs-interval="6000">
    <div class="carousel-item active">
      <img src="https://www.touchbistro.com/wp-content/uploads/2021/08/restaurant-interior-design-ideas-thumbnail.jpg">
    </div>
    <div class="carousel-item">
      <img src="https://samacharnama.com/static/c1e/client/79965/uploaded_original/36857763e7b1a3b29c768a449c5b0399.jpg" class="s">
    </div>
    <div class="carousel-item">
      <img src="https://img.freepik.com/free-photo/happy-waiter-serving-food-group-cheerful-friends-pub_637285-12525.jpg" class="s1">
    </div>
  </div>
  
  
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>

</body>
</html>

