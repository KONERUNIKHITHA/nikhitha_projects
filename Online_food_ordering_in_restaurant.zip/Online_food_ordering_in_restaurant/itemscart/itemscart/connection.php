<?php 
	$conn = mysqli_connect("localhost", "root", "", "cart") or die('connection failed');
?>