<?php 
	include 'connection.php';

	
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>add products</title>
</head>
<body>
	<?php include 'header.php'; ?>
	<div class="cart-container">
		<h1>All Ordered Items</h1>
		<table>
			<thead>
				<!-- <th>image</th> -->
				<th>Address</th>
                <th>Ordered Items</th>
				<th>Total Price</th>
			</thead>
			<tbody>
				<?php 
					$select_cart = mysqli_query($conn, "SELECT * FROM `orders`");
					$grand_total=0;
					if (mysqli_num_rows($select_cart)>0) {
						while($fetch_cart=mysqli_fetch_assoc($select_cart)){


				?>
				<tr>
					<td><?php echo $fetch_cart['tableno']; ?></td>
                    <td><?php echo $fetch_cart['total_products']; ?></td>
					<td>$<?php echo $fetch_cart['total_price']; ?>/-</td>	
				</tr>
                <?php 
						}
					}
				?>
				
			</tbody>
		</table>
	</div>
</body>
</html>
